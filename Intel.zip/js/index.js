document.getElementById("file1").onchange = function() {
    document.getElementById("uploadFile1").value = document.getElementById("file").value;
}